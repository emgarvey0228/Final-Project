# Final-Project

Welcome to the year 2020 where some people around the world actually thought that the delicious bottled Corona drink caused a Global Pandemic. This mini game called "Ronies with the Homies" was created by Emily Garvey, Dalton Gobel, and Malik Lyu on 4/27- 4/29 for our Game Technoogy class (MSCH-C220) at Indiana University. 

Developing this game was challenging due to so many factors. For starters, collaborating with each other while we were all in different time zones was difficult but not only did we have to accommodate everyone's schedule we also had to add in the fact that we also only had 48 hours to create a playable game. We all also felt as a group that school has been overwhelming recently and we didn't have much experience with working with code and assets, aside from this course. However, we felt like we did a pretty good job for the inconveniences we had to figure out prior to completing our project. 

Since the theme of our Game Jam was Coronavirus, we decided that we wanted to have fun with it. This game consists of a user-controlled player who's objective is to pick up limes for his/her beverage. But watch out! Make sure you stay at least "6 feet" away from everyone else!
